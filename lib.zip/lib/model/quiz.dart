import 'package:countries_quiz_app/model/summary.dart';

import 'question.dart';

class Quiz {
  int? total;
  List<Question>? questions;
  int current = -1;
  Summary? summary;

  Quiz({this.questions}) {
    total = questions!.length;
  }

  Question? next() {
    current++;

    if (current < total!) {
      return questions![current];
    }

    // make summary
    var score = 0;
    for (var question in questions!) {
      if (question.isCorrect()) {
        score++;
      }
    }
    summary = Summary(total: total, score: score);

    return null;
  }
}
