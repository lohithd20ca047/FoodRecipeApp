import 'package:countries_quiz_app/model/country.dart';

class Question {
  Country? question;

  List<Country>? answers;

  Country? selectedAnswer;

  Question({this.question, this.answers});

  bool isCorrect() => selectedAnswer == question;
}
