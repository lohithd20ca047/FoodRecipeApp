import 'package:countries_quiz_app/view/summary_page.dart';
import 'package:flutter/material.dart';

import '../model/quiz.dart';
import '../service/quiz_serivce.dart';

class QuizPage extends StatefulWidget {
  final Quiz? quiz;
  const QuizPage({Key? key, required this.quiz}) : super(key: key);

  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  @override
  Widget build(BuildContext context) {
    var current = widget.quiz!.current + 1;
    if (current == 0) current = 1;
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text('Question $current of $numberOfQuestions'),
      ),
      body: getQuestion(),
    );
  }

  Widget getQuestion() {
    var question = widget.quiz!.next();

    if (question == null) {
      Future.delayed(const Duration(seconds: 2)).then((value) {
        Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (context) {
            return SummaryPage(
              summary: widget.quiz!.summary!,
            );
          },
        ));
      });

      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    var widgets = <Widget>[];

    var flagUrl = question.question!.flags!.png!;

    var image = Card(
      child: Container(
        decoration: BoxDecoration(border: Border.all()),
        margin: const EdgeInsets.all(30),
        padding: const EdgeInsets.all(5),
        child: Image.network(
          flagUrl,
          //height: 400,
        ),
      ),
    );

    widgets.add(image);

    for (var i = 0; i < 4; i++) {
      var rowWidget = Row(
        children: [
          Expanded(
              child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    question.selectedAnswer = question.answers![i];
                  });
                },
                child: SizedBox(
                  height: 50,
                  child: Center(
                    child: Text(
                      question.answers![i].name!.common!,
                      style: const TextStyle(fontSize: 20),
                    ),
                  ),
                )),
          )),
        ],
      );

      widgets.add(rowWidget);
    }

    return SingleChildScrollView(
      child: Column(children: widgets),
    );
  }
}
