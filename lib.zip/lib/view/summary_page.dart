import 'package:countries_quiz_app/model/summary.dart';
import 'package:countries_quiz_app/view/home_page.dart';
import 'package:flutter/material.dart';

class SummaryPage extends StatefulWidget {
  final Summary? summary;
  const SummaryPage({Key? key, required this.summary}) : super(key: key);

  @override
  _SummaryPageState createState() => _SummaryPageState();
}

class _SummaryPageState extends State<SummaryPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text('Summary'),
      ),
      body: getResult(),
    );
  }

  Widget getResult() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Center(
            child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text('Total:  ${widget.summary!.total!}'),
        )),
        Center(
            child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text('Score: ${widget.summary!.score!}'),
        )),
        Center(
            child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
              'Percentage: ${widget.summary!.getPercentage().toStringAsFixed(2)} %'),
        )),
        ElevatedButton(
            onPressed: () {
              Navigator.pushReplacement(context, MaterialPageRoute(
                builder: (context) {
                  return const HomePage();
                },
              ));
            },
            child: const Text('Home'))
      ],
    );
  }
}
