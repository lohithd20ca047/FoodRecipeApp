import 'package:countries_quiz_app/service/quiz_serivce.dart';
import 'package:countries_quiz_app/view/quiz_page.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Center(
            child: Text(
          'QUIZ',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
        )),
      ),
      body: getbody(),
    );
  }

  Widget getbody() {
    return Center(
      child: ElevatedButton(
        child: const Text('Start Quiz'),
        onPressed: () async {
          var quiz = await createQuiz(context);

          Navigator.pushReplacement(context, MaterialPageRoute(
            builder: (context) {
              return QuizPage(quiz: quiz);
            },
          ));
        },
      ),
    );
  }
}
