import 'package:flutter/material.dart';

import 'view/quiz_app.dart';

void main() {
  runApp(const QuizApp());
}
