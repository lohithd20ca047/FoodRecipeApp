import 'dart:math';

import 'package:countries_quiz_app/model/question.dart';
import 'package:countries_quiz_app/model/quiz.dart';
import 'package:flutter/cupertino.dart';

import '../model/country.dart';
import 'country_service.dart';

///
///  Get a random country
///
Country getRandomCountry(List<Country> countries, List<Country> exclusion) {
  var countriesCopy = <Country>[];
  countriesCopy.addAll(countries);

  countriesCopy.removeWhere((element) => exclusion.contains(element));

  var rng = Random();
  var index = rng.nextInt(countriesCopy.length);
  return countriesCopy[index];
}

///
///  if we give a,b,c,d it will give c,d,b,a (random order)
///
List<Country> randomize(List<Country> items) {
  var newList = <Country>[];
  for (var i = 0; i < items.length; i++) {
    var country = getRandomCountry(items, newList);
    newList.add(country);
  }

  return newList;
}

const numberOfQuestions = 3;

Future<Quiz> createQuiz(BuildContext context) async {
  var questions = <Question>[];

  var countries = await readCountries(context);
  var exclusion = <Country>[];

  for (var i = 0; i < numberOfQuestions; i++) {
    var c1 = getRandomCountry(countries, exclusion);
    exclusion.add(c1);

    var c2 = getRandomCountry(countries, exclusion);
    var c3 = getRandomCountry(countries, exclusion);
    var c4 = getRandomCountry(countries, exclusion);

    var choices = randomize(<Country>[c1, c2, c3, c4]);

    var q = Question(question: c1, answers: choices);
    questions.add(q);
  }

  var quiz = Quiz(questions: questions);
  return quiz;
}
